from bitmex_kollector.kollector import Kollector
from bitmex_kollector.khan import Khan
