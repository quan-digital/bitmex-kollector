from bitmex_kollector.kollector import Kollector
import bitmex_kollector.settings as settings
